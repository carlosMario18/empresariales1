package interfaz;

public interface MedicoG {
     int asignarConsultorio();
}
