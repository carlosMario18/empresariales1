package interfaz;

public interface Observador {
    public  void update();
}
